import { useState } from "react";

// ── LOGO (hosted on your server — replace with actual URL after deploy)
const LOGO_URL = process.env.PUBLIC_URL + "/logo.png";

// ── DATA ────────────────────────────────────────────────────────────────────
const REGIONS = [
  { id: "conakry",    name: "Conakry",    emoji: "🏙️", shops: ["Younma Conakry Centre", "Younma Ratoma", "Younma Matoto", "Younma Kaloum"] },
  { id: "kindia",     name: "Kindia",     emoji: "🏘️", shops: ["Younma Kindia Ville", "Younma Kindia Marché Central"] },
  { id: "boke",       name: "Boké",       emoji: "🏗️", shops: ["Younma Boké Centre", "Younma Kamsar"] },
  { id: "labe",       name: "Labé",       emoji: "⛰️", shops: ["Younma Labé Centre", "Younma Pita"] },
  { id: "mamou",      name: "Mamou",      emoji: "🌿", shops: ["Younma Mamou Centre", "Younma Dalaba"] },
  { id: "faranah",    name: "Faranah",    emoji: "🌾", shops: ["Younma Faranah Centre", "Younma Kissidougou"] },
  { id: "kankan",     name: "Kankan",     emoji: "🌅", shops: ["Younma Kankan Centre", "Younma Siguiri", "Younma Kouroussa"] },
  { id: "nzerekore",  name: "Nzérékoré",  emoji: "🌳", shops: ["Younma Nzérékoré Centre", "Younma Guéckédou", "Younma Macenta"] },
];

const CATEGORIES = [
  { id: "furniture",       name: "Mobilier",           icon: "🛋️", color: "#F7941D", desc: "Canapés, lits, armoires, tables" },
  { id: "materials",       name: "Matériaux",           icon: "🧱", color: "#1B4F72", desc: "Ciment, fer, sable, carreaux" },
  { id: "plumbing",        name: "Plomberie",           icon: "🔧", color: "#2E86AB", desc: "Tuyaux, robinets, lavabos" },
  { id: "electromenager",  name: "Électroménager",      icon: "📺", color: "#117864", desc: "Frigos, climatiseurs, machines" },
  { id: "electric",        name: "Électricité",         icon: "💡", color: "#D4AC0D", desc: "Câbles, prises, disjoncteurs" },
  { id: "paint",           name: "Peinture",            icon: "🖌️", color: "#A04000", desc: "Peintures, enduits, vernis" },
  { id: "tools",           name: "Outillage",           icon: "🔨", color: "#6C3483", desc: "Marteaux, perceuses, scies" },
  { id: "door",            name: "Portes & Fenêtres",   icon: "🚪", color: "#1A5276", desc: "Portes, fenêtres, grilles" },
];

const PRODUCTS = [
  { id:1,  name:"Ciment Portland 50kg",       category:"materials",      price:85000,  region:"conakry",   img:"🧱", rating:4.8, unit:"sac",   stock:200 },
  { id:2,  name:"Fer à béton 12mm",           category:"materials",      price:120000, region:"conakry",   img:"🔩", rating:4.6, unit:"barre",  stock:500 },
  { id:3,  name:"Carrelage Sol 60x60",        category:"materials",      price:45000,  region:"kindia",    img:"⬜", rating:4.5, unit:"m²",     stock:300 },
  { id:4,  name:"Climatiseur 1.5 CV",         category:"electromenager", price:2800000,region:"conakry",   img:"❄️", rating:4.9, unit:"unité",  stock:15  },
  { id:5,  name:"Réfrigérateur 200L",         category:"electromenager", price:3500000,region:"conakry",   img:"🧊", rating:4.7, unit:"unité",  stock:8   },
  { id:6,  name:"Canapé 3 places",            category:"furniture",      price:1200000,region:"conakry",   img:"🛋️", rating:4.4, unit:"unité",  stock:12  },
  { id:7,  name:"Lit 2 places + matelas",     category:"furniture",      price:1800000,region:"kankan",    img:"🛏️", rating:4.6, unit:"unité",  stock:7   },
  { id:8,  name:"Robinet Mélangeur Inox",     category:"plumbing",       price:95000,  region:"conakry",   img:"🚿", rating:4.3, unit:"unité",  stock:50  },
  { id:9,  name:"Tuyau PVC 100mm (6m)",       category:"plumbing",       price:55000,  region:"boke",      img:"🔧", rating:4.5, unit:"barre",  stock:100 },
  { id:10, name:"Peinture Murale 20L",        category:"paint",          price:320000, region:"conakry",   img:"🪣", rating:4.8, unit:"bidon",  stock:30  },
  { id:11, name:"Perceuse Électrique 750W",   category:"tools",          price:450000, region:"labe",      img:"🔨", rating:4.7, unit:"unité",  stock:20  },
  { id:12, name:"Tableau Électrique 12P",     category:"electric",       price:380000, region:"conakry",   img:"⚡", rating:4.6, unit:"unité",  stock:25  },
  { id:13, name:"Porte Blindée Acier",        category:"door",           price:2200000,region:"conakry",   img:"🚪", rating:4.9, unit:"unité",  stock:5   },
  { id:14, name:"Fenêtre Alu 100×120",        category:"door",           price:850000, region:"mamou",     img:"🪟", rating:4.5, unit:"unité",  stock:18  },
  { id:15, name:"Armoire 3 portes bois",      category:"furniture",      price:1500000,region:"faranah",   img:"🗄️", rating:4.3, unit:"unité",  stock:9   },
  { id:16, name:"Machine à laver 7kg",        category:"electromenager", price:4200000,region:"conakry",   img:"🫧", rating:4.8, unit:"unité",  stock:6   },
  { id:17, name:"Tôle ondulée 5kg",           category:"materials",      price:40000,  region:"kindia",    img:"🏗️", rating:4.7, unit:"feuille",stock:500 },
  { id:18, name:"Tôle ondulée 6kg",           category:"materials",      price:54000,  region:"kindia",    img:"🏗️", rating:4.8, unit:"feuille",stock:400 },
  { id:19, name:"Câble électrique 2.5mm²",    category:"electric",       price:75000,  region:"conakry",   img:"🔌", rating:4.6, unit:"rouleau",stock:80  },
  { id:20, name:"Table à manger 6 places",    category:"furniture",      price:2100000,region:"conakry",   img:"🍽️", rating:4.5, unit:"unité",  stock:6   },
];

const fmt = (p) => new Intl.NumberFormat("fr-GN").format(p) + " GNF";

// ── STYLES ──────────────────────────────────────────────────────────────────
const S = {
  btnOrange: {
    background: "linear-gradient(135deg,#F7941D,#e07b0a)",
    color: "white", border: "none", borderRadius: 12,
    padding: "12px 22px", fontWeight: 800, cursor: "pointer",
    fontSize: 14, boxShadow: "0 4px 14px rgba(247,148,29,0.4)",
    fontFamily: "inherit",
  },
  btnNavy: {
    background: "linear-gradient(135deg,#1B4F72,#0e2d42)",
    color: "white", border: "none", borderRadius: 12,
    padding: "12px 22px", fontWeight: 800, cursor: "pointer",
    fontSize: 14, fontFamily: "inherit",
  },
  input: {
    border: "2px solid #e2e8f0", borderRadius: 11,
    padding: "11px 14px", fontSize: 14, outline: "none",
    fontFamily: "inherit", width: "100%",
  },
  select: {
    border: "2px solid #e2e8f0", borderRadius: 11,
    padding: "11px 14px", fontSize: 14, outline: "none",
    fontFamily: "inherit", background: "white",
  },
  card: {
    background: "white", borderRadius: 18,
    boxShadow: "0 4px 18px rgba(0,0,0,0.08)",
    overflow: "hidden", transition: "transform 0.2s, box-shadow 0.2s",
  },
};

// ── PRODUCT CARD COMPONENT ───────────────────────────────────────────────────
function ProductCard({ product, onAdd }) {
  const cat    = CATEGORIES.find(c => c.id === product.category);
  const region = REGIONS.find(r => r.id === product.region);
  const [hover, setHover] = useState(false);
  return (
    <div
      style={{ ...S.card, display:"flex", flexDirection:"column",
               transform: hover ? "translateY(-4px)" : "none",
               boxShadow: hover ? "0 8px 30px rgba(0,0,0,0.13)" : S.card.boxShadow }}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
    >
      <div style={{ background:`linear-gradient(135deg,${cat?.color}18,${cat?.color}35)`,
                    padding:"28px 0", textAlign:"center", fontSize:50 }}>
        {product.img}
      </div>
      <div style={{ padding:"14px 14px 16px", flex:1, display:"flex", flexDirection:"column" }}>
        <div style={{ display:"flex", gap:5, flexWrap:"wrap", marginBottom:8 }}>
          <span style={{ background:cat?.color+"20", color:cat?.color,
                         padding:"3px 8px", borderRadius:20, fontSize:11, fontWeight:700 }}>
            {cat?.icon} {cat?.name}
          </span>
          <span style={{ background:"#eff6ff", color:"#3b82f6",
                         padding:"3px 8px", borderRadius:20, fontSize:11, fontWeight:700 }}>
            {region?.emoji} {region?.name}
          </span>
        </div>
        <div style={{ fontWeight:800, fontSize:14, color:"#1B4F72", marginBottom:6, flex:1 }}>
          {product.name}
        </div>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:4 }}>
          <span style={{ color:"#F7941D", fontWeight:900, fontSize:15 }}>{fmt(product.price)}</span>
          <span style={{ color:"#aaa", fontSize:11 }}>/{product.unit}</span>
        </div>
        <div style={{ color:"#999", fontSize:12, marginBottom:10 }}>
          ⭐ {product.rating} · {product.stock} en stock
        </div>
        <button style={{ ...S.btnOrange, width:"100%", padding:"10px", fontSize:13 }}
                onClick={() => onAdd(product)}>
          🛒 Ajouter
        </button>
      </div>
    </div>
  );
}

// ── MAIN APP ─────────────────────────────────────────────────────────────────
export default function App() {
  const [page,       setPage]       = useState("home");
  const [cart,       setCart]       = useState([]);
  const [selRegion,  setSelRegion]  = useState(null);
  const [selCat,     setSelCat]     = useState(null);
  const [search,     setSearch]     = useState("");
  const [payStep,    setPayStep]    = useState(0);
  const [phone,      setPhone]      = useState("");
  const [done,       setDone]       = useState(false);
  const [ship,       setShip]       = useState({ name:"", address:"", region:"kindia" });

  const addToCart = (p) => setCart(c => {
    const e = c.find(i => i.id === p.id);
    return e ? c.map(i => i.id === p.id ? {...i, qty:i.qty+1} : i)
             : [...c, {...p, qty:1}];
  });
  const remFromCart = (id) => setCart(c => c.filter(i => i.id !== id));
  const upQty = (id, d) => setCart(c => c.map(i => i.id === id ? {...i, qty:Math.max(1,i.qty+d)} : i));
  const total = cart.reduce((s,i) => s + i.price * i.qty, 0);
  const cartN = cart.reduce((s,i) => s + i.qty, 0);

  const filtered = PRODUCTS.filter(p =>
    (!selRegion || p.region === selRegion) &&
    (!selCat    || p.category === selCat)  &&
    (!search    || p.name.toLowerCase().includes(search.toLowerCase()))
  );

  const navigate = (pg) => { setPage(pg); window.scrollTo(0,0); };

  return (
    <div style={{ fontFamily:"'Nunito',sans-serif", background:"#f1f5f9", minHeight:"100vh" }}>

      {/* ── HEADER ── */}
      <header style={{ background:"white", padding:"0 16px", display:"flex",
                       alignItems:"center", justifyContent:"space-between",
                       position:"sticky", top:0, zIndex:999,
                       boxShadow:"0 2px 12px rgba(0,0,0,0.09)", height:62 }}>
        <div style={{ display:"flex", alignItems:"center", gap:8, cursor:"pointer" }}
             onClick={() => navigate("home")}>
          <img src={LOGO_URL} alt="Younma" style={{ height:46 }}
               onError={e => { e.target.style.display='none'; }} />
          <div>
            <div style={{ fontWeight:900, fontSize:16, color:"#1B4F72" }}>Younma</div>
            <div style={{ fontSize:9, letterSpacing:2, color:"#F7941D", fontWeight:700 }}>CONSTRUCTION</div>
          </div>
        </div>
        <nav style={{ display:"flex", gap:4 }}>
          {[["home","🏠","Accueil"],["shop","🛒","Boutique"],
            ["regions","📍","Régions"],["cart","🛍️","Panier"]].map(([id,ic,lb]) => (
            <button key={id} onClick={() => navigate(id)}
                    style={{ background:page===id?"#F7941D":"transparent",
                             color:page===id?"white":"#555",
                             border:"none", borderRadius:9, padding:"7px 10px",
                             cursor:"pointer", fontWeight:700, fontSize:13,
                             position:"relative", display:"flex", alignItems:"center",
                             gap:4, fontFamily:"inherit" }}>
              {ic}
              <span style={{ display:"none" }} className="nav-label">{lb}</span>
              {id==="cart" && cartN > 0 && (
                <span style={{ position:"absolute", top:-5, right:-5,
                               background:"#ef4444", color:"white",
                               borderRadius:"50%", width:18, height:18,
                               fontSize:10, fontWeight:900,
                               display:"flex", alignItems:"center", justifyContent:"center" }}>
                  {cartN}
                </span>
              )}
            </button>
          ))}
        </nav>
      </header>

      {/* ══ HOME ══════════════════════════════════════════════════════════════ */}
      {page === "home" && (
        <div>
          {/* Hero */}
          <div style={{ background:"linear-gradient(135deg,#1B4F72 0%,#0e2d42 55%,#c16b00 100%)",
                        padding:"52px 20px 64px", textAlign:"center",
                        position:"relative", overflow:"hidden" }}>
            <div style={{ position:"absolute", top:-50, right:-50, width:220, height:220,
                          borderRadius:"50%", background:"rgba(247,148,29,0.12)" }} />
            <img src={LOGO_URL} alt="Younma"
                 style={{ height:110, objectFit:"contain", marginBottom:18,
                          filter:"drop-shadow(0 6px 18px rgba(0,0,0,0.35))" }}
                 onError={e => { e.target.style.display='none'; }} />
            <h1 style={{ color:"white", fontSize:"clamp(22px,5vw,36px)",
                         fontWeight:900, lineHeight:1.2 }}>
              Tout pour votre maison
            </h1>
            <p style={{ color:"rgba(255,255,255,0.78)", fontSize:16,
                        margin:"12px auto 26px", maxWidth:480 }}>
              Matériaux de construction, mobilier, plomberie, électroménager<br />
              Livré dans les <strong>8 régions de Guinée</strong> 🇬🇳
            </p>
            <div style={{ display:"flex", gap:12, justifyContent:"center", flexWrap:"wrap" }}>
              <button style={{ ...S.btnOrange, fontSize:16, padding:"14px 28px" }}
                      onClick={() => navigate("shop")}>
                🛒 Acheter maintenant
              </button>
              <button style={{ background:"rgba(255,255,255,0.15)", color:"white",
                               border:"2px solid rgba(255,255,255,0.3)", borderRadius:12,
                               padding:"14px 28px", fontWeight:800, cursor:"pointer",
                               fontSize:16, fontFamily:"inherit" }}
                      onClick={() => navigate("regions")}>
                📍 Nos boutiques
              </button>
            </div>
          </div>

          {/* Orange Money banner */}
          <div style={{ background:"linear-gradient(90deg,#e65c00,#f9a000)",
                        padding:"14px 20px", display:"flex", alignItems:"center",
                        justifyContent:"center", gap:14, flexWrap:"wrap" }}>
            <span style={{ fontSize:26 }}>📱</span>
            <div>
              <div style={{ color:"white", fontWeight:900, fontSize:16 }}>
                Paiement Orange Money disponible
              </div>
              <div style={{ color:"rgba(255,255,255,0.85)", fontSize:13 }}>
                Rapide, sécurisé, partout en Guinée
              </div>
            </div>
            <span style={{ background:"white", color:"#e65c00",
                           padding:"7px 16px", borderRadius:24,
                           fontWeight:900, fontSize:13 }}>
              ✓ Sécurisé
            </span>
          </div>

          {/* Stats */}
          <div style={{ background:"#1B4F72", padding:"32px 20px",
                        display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(120px,1fr))",
                        gap:16, textAlign:"center" }}>
            {[["8","Régions"],["20+","Produits"],["24h","Livraison"],["🟠","Orange Money"]].map(([n,l]) => (
              <div key={l}>
                <div style={{ fontSize:32, fontWeight:900, color:"#F7941D" }}>{n}</div>
                <div style={{ color:"rgba(255,255,255,0.75)", fontWeight:700, fontSize:13, marginTop:4 }}>{l}</div>
              </div>
            ))}
          </div>

          {/* Categories */}
          <div style={{ padding:"32px 16px" }}>
            <h2 style={{ fontSize:22, fontWeight:900, color:"#1B4F72", marginBottom:6 }}>
              Nos Catégories
            </h2>
            <p style={{ color:"#94a3b8", marginBottom:18, fontSize:14 }}>
              Tout ce qu'il faut pour construire et aménager
            </p>
            <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(120px,1fr))", gap:10 }}>
              {CATEGORIES.map(cat => (
                <div key={cat.id}
                     onClick={() => { setSelCat(cat.id); navigate("shop"); }}
                     style={{ background:"white", borderRadius:14, padding:"18px 10px",
                              textAlign:"center", cursor:"pointer",
                              boxShadow:"0 3px 12px rgba(0,0,0,0.07)",
                              transition:"transform 0.2s" }}>
                  <div style={{ fontSize:36, marginBottom:7 }}>{cat.icon}</div>
                  <div style={{ fontWeight:800, fontSize:12, color:"#1B4F72" }}>{cat.name}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Featured products */}
          <div style={{ padding:"0 16px 40px" }}>
            <h2 style={{ fontSize:22, fontWeight:900, color:"#1B4F72", marginBottom:18 }}>
              ⭐ Produits Populaires
            </h2>
            <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(175px,1fr))", gap:14 }}>
              {PRODUCTS.slice(0,8).map(p => <ProductCard key={p.id} product={p} onAdd={addToCart} />)}
            </div>
            <div style={{ textAlign:"center", marginTop:22 }}>
              <button style={{ ...S.btnNavy, padding:"13px 36px", fontSize:15 }}
                      onClick={() => navigate("shop")}>
                Voir tous les produits →
              </button>
            </div>
          </div>

          {/* WhatsApp CTA */}
          <div style={{ background:"#0e2d42", padding:"36px 20px", textAlign:"center" }}>
            <div style={{ fontSize:40, marginBottom:12 }}>💬</div>
            <h3 style={{ color:"white", fontSize:20, fontWeight:900, marginBottom:8 }}>
              Envoyez votre liste sur WhatsApp
            </h3>
            <p style={{ color:"rgba(255,255,255,0.7)", fontSize:14, marginBottom:20 }}>
              Envoyez-nous votre liste d'achat et nous vous ferons le devis en quelques minutes
            </p>
            <a href="https://wa.me/224610191165"
               target="_blank" rel="noreferrer"
               style={{ ...S.btnOrange, textDecoration:"none", display:"inline-block",
                        fontSize:16, padding:"14px 32px" }}>
              📱 +224 610 19 11 65
            </a>
          </div>
        </div>
      )}

      {/* ══ SHOP ══════════════════════════════════════════════════════════════ */}
      {page === "shop" && (
        <div style={{ padding:"22px 16px" }}>
          <h2 style={{ fontSize:22, fontWeight:900, color:"#1B4F72", marginBottom:16 }}>🛒 Boutique</h2>

          {/* Filters */}
          <div style={{ background:"white", borderRadius:14, padding:14, marginBottom:14,
                        display:"flex", flexWrap:"wrap", gap:10 }}>
            <input placeholder="🔍 Rechercher..." value={search}
                   onChange={e => setSearch(e.target.value)}
                   style={{ ...S.input, flex:"1 1 160px" }} />
            <select value={selRegion||""} onChange={e => setSelRegion(e.target.value||null)}
                    style={{ ...S.select, flex:"1 1 130px" }}>
              <option value="">📍 Toutes régions</option>
              {REGIONS.map(r => <option key={r.id} value={r.id}>{r.emoji} {r.name}</option>)}
            </select>
            <select value={selCat||""} onChange={e => setSelCat(e.target.value||null)}
                    style={{ ...S.select, flex:"1 1 130px" }}>
              <option value="">🏷️ Catégories</option>
              {CATEGORIES.map(cat => <option key={cat.id} value={cat.id}>{cat.icon} {cat.name}</option>)}
            </select>
            {(selRegion||selCat||search) && (
              <button onClick={() => { setSelRegion(null); setSelCat(null); setSearch(""); }}
                      style={{ background:"#fee2e2", color:"#dc2626", border:"none",
                               borderRadius:10, padding:"10px 14px", fontWeight:800,
                               cursor:"pointer", fontFamily:"inherit" }}>
                ✕ Effacer
              </button>
            )}
          </div>

          {/* Category pills */}
          <div style={{ display:"flex", gap:7, overflowX:"auto", paddingBottom:8, marginBottom:14 }}>
            {[{id:null,name:"Tout",icon:"🔎"},...CATEGORIES].map(cat => (
              <button key={cat.id||"all"} onClick={() => setSelCat(cat.id)}
                      style={{ background:selCat===cat.id?"#F7941D":"white",
                               color:selCat===cat.id?"white":"#555",
                               border:`2px solid ${selCat===cat.id?"#F7941D":"#e2e8f0"}`,
                               borderRadius:20, padding:"7px 14px", fontWeight:700,
                               cursor:"pointer", whiteSpace:"nowrap", fontSize:12,
                               fontFamily:"inherit" }}>
                {cat.icon} {cat.name}
              </button>
            ))}
          </div>

          <p style={{ color:"#94a3b8", fontSize:13, marginBottom:14, fontWeight:700 }}>
            {filtered.length} produit{filtered.length!==1?"s":""}
          </p>

          <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(175px,1fr))", gap:14 }}>
            {filtered.map(p => <ProductCard key={p.id} product={p} onAdd={addToCart} />)}
          </div>
          {!filtered.length && (
            <div style={{ textAlign:"center", padding:"60px 0", color:"#cbd5e1" }}>
              <div style={{ fontSize:56 }}>😕</div>
              <div style={{ fontWeight:700, fontSize:18, marginTop:10 }}>Aucun produit trouvé</div>
            </div>
          )}
        </div>
      )}

      {/* ══ REGIONS ═══════════════════════════════════════════════════════════ */}
      {page === "regions" && (
        <div style={{ padding:"22px 16px" }}>
          <h2 style={{ fontSize:22, fontWeight:900, color:"#1B4F72", marginBottom:6 }}>
            📍 Boutiques en Guinée
          </h2>
          <p style={{ color:"#94a3b8", fontSize:14, marginBottom:20 }}>
            8 régions administratives couvertes 🇬🇳
          </p>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(260px,1fr))", gap:14 }}>
            {REGIONS.map(r => (
              <div key={r.id} style={{ ...S.card, padding:22 }}>
                <div style={{ display:"flex", alignItems:"center", gap:12, marginBottom:14 }}>
                  <div style={{ fontSize:34 }}>{r.emoji}</div>
                  <div>
                    <div style={{ fontWeight:900, fontSize:18, color:"#1B4F72" }}>{r.name}</div>
                    <div style={{ color:"#94a3b8", fontSize:12 }}>
                      {r.shops.length} boutique{r.shops.length>1?"s":""}
                    </div>
                  </div>
                </div>
                {r.shops.map(s => (
                  <div key={s} style={{ background:"#f8fafc", borderRadius:9,
                                        padding:"9px 13px", fontSize:13, color:"#475569",
                                        fontWeight:600, marginBottom:6,
                                        display:"flex", gap:8, alignItems:"center" }}>
                    <span style={{ color:"#F7941D" }}>📦</span>{s}
                  </div>
                ))}
                <button style={{ ...S.btnOrange, width:"100%", marginTop:14, padding:"11px" }}
                        onClick={() => { setSelRegion(r.id); navigate("shop"); }}>
                  Voir les produits →
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ══ CART ══════════════════════════════════════════════════════════════ */}
      {page === "cart" && !done && (
        <div style={{ padding:"22px 16px", maxWidth:580, margin:"0 auto" }}>
          <h2 style={{ fontSize:22, fontWeight:900, color:"#1B4F72", marginBottom:18 }}>
            🛍️ Mon Panier
          </h2>
          {cart.length === 0 ? (
            <div style={{ textAlign:"center", padding:"60px 0" }}>
              <div style={{ fontSize:68 }}>🛒</div>
              <div style={{ fontWeight:700, fontSize:18, color:"#cbd5e1", marginTop:12 }}>
                Panier vide
              </div>
              <button style={{ ...S.btnOrange, marginTop:20 }} onClick={() => navigate("shop")}>
                Continuer les achats
              </button>
            </div>
          ) : (
            <>
              {cart.map(item => (
                <div key={item.id}
                     style={{ background:"white", borderRadius:16, padding:14,
                              marginBottom:10, display:"flex", alignItems:"center",
                              gap:12, boxShadow:"0 2px 10px rgba(0,0,0,0.06)" }}>
                  <div style={{ fontSize:36 }}>{item.img}</div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontWeight:800, fontSize:14, color:"#1B4F72" }}>{item.name}</div>
                    <div style={{ color:"#F7941D", fontWeight:900, marginTop:3, fontSize:14 }}>
                      {fmt(item.price)}
                    </div>
                  </div>
                  <div style={{ display:"flex", alignItems:"center", gap:6 }}>
                    <button onClick={() => upQty(item.id,-1)}
                            style={{ width:28,height:28,borderRadius:"50%",
                                     border:"2px solid #e2e8f0",background:"white",
                                     fontWeight:900,cursor:"pointer",fontFamily:"inherit" }}>−</button>
                    <span style={{ fontWeight:900, minWidth:18, textAlign:"center" }}>{item.qty}</span>
                    <button onClick={() => upQty(item.id,1)}
                            style={{ width:28,height:28,borderRadius:"50%",border:"none",
                                     background:"#F7941D",color:"white",fontWeight:900,
                                     cursor:"pointer",fontFamily:"inherit" }}>+</button>
                    <button onClick={() => remFromCart(item.id)}
                            style={{ width:28,height:28,borderRadius:8,border:"none",
                                     background:"#fee2e2",color:"#dc2626",fontWeight:900,
                                     cursor:"pointer",fontFamily:"inherit" }}>✕</button>
                  </div>
                </div>
              ))}

              <div style={{ background:"white", borderRadius:18, padding:20, marginTop:16,
                            boxShadow:"0 4px 18px rgba(0,0,0,0.08)" }}>
                <div style={{ display:"flex", justifyContent:"space-between",
                              fontSize:18, fontWeight:900, color:"#1B4F72",
                              marginBottom:16, paddingBottom:14,
                              borderBottom:"2px dashed #f1f5f9" }}>
                  <span>Total commande</span>
                  <span style={{ color:"#F7941D" }}>{fmt(total)}</span>
                </div>

                {/* Shipping form */}
                <div style={{ marginBottom:16 }}>
                  <div style={{ fontWeight:800, fontSize:14, color:"#475569", marginBottom:10 }}>
                    🚚 Informations de livraison
                  </div>
                  <input placeholder="Nom complet *" value={ship.name}
                         onChange={e => setShip({...ship, name:e.target.value})}
                         style={{ ...S.input, marginBottom:8 }} />
                  <input placeholder="Adresse / Quartier *" value={ship.address}
                         onChange={e => setShip({...ship, address:e.target.value})}
                         style={{ ...S.input, marginBottom:8 }} />
                  <select value={ship.region} onChange={e => setShip({...ship, region:e.target.value})}
                          style={{ ...S.select, width:"100%" }}>
                    {REGIONS.map(r => <option key={r.id} value={r.id}>{r.emoji} {r.name}</option>)}
                  </select>
                </div>

                {/* Orange Money */}
                <div style={{ background:"linear-gradient(135deg,#fff7ed,#ffedd5)",
                              borderRadius:14, padding:14, marginBottom:16,
                              display:"flex", gap:12, alignItems:"center",
                              border:"2px solid #fed7aa" }}>
                  <span style={{ fontSize:30 }}>🟠</span>
                  <div>
                    <div style={{ fontWeight:900, color:"#c2410c", fontSize:15 }}>Orange Money</div>
                    <div style={{ fontSize:13, color:"#92400e" }}>Paiement mobile sécurisé en Guinée</div>
                  </div>
                </div>

                {payStep === 0 && (
                  <button style={{ ...S.btnOrange, width:"100%", padding:"14px", fontSize:15 }}
                          onClick={() => {
                            if (ship.name && ship.address) setPayStep(1);
                            else alert("Remplissez vos informations de livraison");
                          }}>
                    📱 Payer {fmt(total)} par Orange Money
                  </button>
                )}
                {payStep === 1 && (
                  <div>
                    <div style={{ fontWeight:800, color:"#475569", marginBottom:8, fontSize:14 }}>
                      Entrez votre numéro Orange Money :
                    </div>
                    <input placeholder="Ex: 621 00 00 00" value={phone}
                           onChange={e => setPhone(e.target.value)}
                           style={{ ...S.input, marginBottom:12 }} />
                    <button style={{ ...S.btnOrange, width:"100%", padding:"13px" }}
                            onClick={() => {
                              if (phone.length >= 9) {
                                setPayStep(2);
                                setTimeout(() => { setDone(true); setCart([]); setPayStep(0); }, 2800);
                              } else alert("Numéro invalide");
                            }}>
                      ✅ Confirmer le paiement
                    </button>
                  </div>
                )}
                {payStep === 2 && (
                  <div style={{ textAlign:"center", padding:"20px 0" }}>
                    <div style={{ fontSize:46 }}>⏳</div>
                    <div style={{ fontWeight:900, color:"#F7941D", fontSize:16, marginTop:10 }}>
                      Traitement Orange Money…
                    </div>
                    <div style={{ color:"#94a3b8", fontSize:13, marginTop:6 }}>
                      Vous recevrez un SMS de confirmation
                    </div>
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      )}

      {/* ══ ORDER SUCCESS ═════════════════════════════════════════════════════ */}
      {page === "cart" && done && (
        <div style={{ padding:"60px 20px", textAlign:"center", maxWidth:480, margin:"0 auto" }}>
          <div style={{ fontSize:76 }}>🎉</div>
          <h2 style={{ fontSize:26, fontWeight:900, color:"#1B4F72", margin:"20px 0 12px" }}>
            Commande confirmée !
          </h2>
          <p style={{ color:"#64748b", fontSize:15 }}>
            Votre paiement Orange Money a été reçu. Livraison sous 24–48h.
          </p>
          <div style={{ background:"#f0fdf4", borderRadius:16, padding:18,
                        margin:"20px 0", border:"2px solid #86efac" }}>
            <div style={{ fontWeight:900, color:"#15803d", fontSize:16 }}>
              ✅ Paiement reçu via Orange Money
            </div>
            <div style={{ color:"#475569", marginTop:6, fontSize:14 }}>
              Livraison : {REGIONS.find(r=>r.id===ship.region)?.name} — {ship.address}
            </div>
          </div>
          <button style={{ ...S.btnOrange, fontSize:15, padding:"14px 32px" }}
                  onClick={() => { setDone(false); navigate("home"); }}>
            Retour à l'accueil
          </button>
        </div>
      )}

      {/* ── FOOTER ── */}
      <footer style={{ background:"#0e2d42", color:"white", padding:"32px 20px", marginTop:40 }}>
        <div style={{ display:"flex", flexWrap:"wrap", gap:24,
                      justifyContent:"space-between", maxWidth:860, margin:"0 auto" }}>
          <div>
            <div style={{ fontWeight:900, fontSize:18, color:"#F7941D", marginBottom:8 }}>
              Younma Construction
            </div>
            <p style={{ color:"rgba(255,255,255,0.55)", fontSize:13, maxWidth:220 }}>
              Votre partenaire de confiance pour la construction et l'aménagement en Guinée.
            </p>
          </div>
          <div>
            <div style={{ fontWeight:800, color:"#F7941D", marginBottom:8, fontSize:13 }}>
              8 Régions
            </div>
            {REGIONS.map(r => (
              <div key={r.id} style={{ color:"rgba(255,255,255,0.5)", fontSize:12, marginBottom:2 }}>
                {r.emoji} {r.name}
              </div>
            ))}
          </div>
          <div>
            <div style={{ fontWeight:800, color:"#F7941D", marginBottom:8, fontSize:13 }}>Contact</div>
            <div style={{ color:"rgba(255,255,255,0.55)", fontSize:13, lineHeight:2.1 }}>
              📞 +224 610 19 11 65<br />
              📧 younma72@gmail.com<br />
              📍 Anc. Gare Voiture, Boutique C012, Kindia<br />
              🟠 Orange Money accepté
            </div>
          </div>
        </div>
        <div style={{ textAlign:"center", marginTop:24,
                      color:"rgba(255,255,255,0.3)", fontSize:12,
                      borderTop:"1px solid rgba(255,255,255,0.08)", paddingTop:16 }}>
          © 2025 Younma Construction · Fièrement guinéen 🇬🇳
        </div>
      </footer>
    </div>
  );
}
