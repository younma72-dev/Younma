# 🏗️ Younma Construction — Application Web

## 🚀 Déploiement sur Vercel (GRATUIT — 30 minutes)

### Étape 1 — Préparer les fichiers
1. Copiez le logo Younma dans le dossier `public/` et nommez-le `logo.png`
2. Vérifiez que vous avez tous ces fichiers :
   ```
   younma-app/
   ├── public/
   │   ├── index.html
   │   └── logo.png         ← AJOUTEZ VOTRE LOGO ICI
   ├── src/
   │   ├── index.js
   │   └── App.js
   ├── package.json
   └── vercel.json
   ```

### Étape 2 — Créer un compte GitHub (gratuit)
1. Allez sur **github.com**
2. Créez un compte gratuit
3. Créez un nouveau repository appelé `younma-app`
4. Uploadez tous les fichiers du dossier `younma-app/`

### Étape 3 — Déployer sur Vercel (gratuit)
1. Allez sur **vercel.com**
2. Cliquez "Sign up" → connectez-vous avec GitHub
3. Cliquez "New Project"
4. Sélectionnez votre repository `younma-app`
5. Cliquez "Deploy"
6. ✅ Votre site est en ligne en 2 minutes !

### Étape 4 — Votre URL
Vercel vous donnera une URL comme :
**https://younma-app.vercel.app**

Partagez cette URL partout : WhatsApp, Facebook, flyers, cartes de visite !

---

## 🌐 Domaine personnalisé (optionnel — ~15$/an)

Pour avoir **www.younma.gn** ou **www.younma.com** :
1. Achetez le domaine sur **namecheap.com** ou **godaddy.com**
2. Dans Vercel → Settings → Domains → ajoutez votre domaine
3. Suivez les instructions DNS de Vercel

---

## 📱 Transformer en App Android (optionnel)

Si vous voulez une vraie application Android :
1. Installez **Android Studio** (gratuit)
2. Utilisez **Capacitor** pour wrapper l'app web
3. Publiez sur **Google Play Store** (25$ frais unique)

---

## ✏️ Modifier les produits et prix

Ouvrez le fichier `src/App.js` et trouvez la section `PRODUCTS` :
```javascript
const PRODUCTS = [
  { id:1, name:"Ciment Portland 50kg", price:85000, ... },
  // Ajoutez vos produits ici
];
```

Modifiez les prix, ajoutez des produits, changez les stocks.

---

## 📞 Support

WhatsApp : +224 610 19 11 65
Email : younma72@gmail.com
